#include "stdafx.h"

DLL_API HANDLE hThread;
DLL_API DWORD nThread;


BOOL APIENTRY DllMain(HINSTANCE hModule, DWORD fdwReason, LPVOID IpReserved)
{
	switch (fdwReason)
		{
		case DLL_PROCESS_ATTACH:	
			OutputDebugString("---In DLL_PROCESS_ATTACH---");

			hThread = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)TickCounter, NULL, 0, &nThread);
			SetThreadPriority(hThread, THREAD_PRIORITY_TIME_CRITICAL);

			iat_hook("winmm.dll", (PROC)timeGetTime, (PROC)MytimeGetTime);
			break;

		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:

			break;
		case DLL_PROCESS_DETACH:
			OutputDebugString("---In DLL_PROCESS_DETACH---");
			iat_hook("winmm.dll", (PROC)MytimeGetTime, (PROC)timeGetTime);
			CloseHandle(hThread);
			break;
		}

		return TRUE;
}