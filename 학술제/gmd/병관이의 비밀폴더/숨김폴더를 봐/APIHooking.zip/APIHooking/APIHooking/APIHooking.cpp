#include "stdafx.h"

DWORD Tick = 0;
DWORD Count = 500;

BOOL iat_hook(LPCSTR dllname, PROC func1, PROC func2)
{
	OutputDebugString("In iat_hook()");

	//MessageBox(0, dllname, "DLL ERROdddddR", 0);
	HMODULE hMod;
	PIMAGE_IMPORT_DESCRIPTOR pIDT;
	DWORD pRVA;
	PBYTE pAddr;
	LPCSTR libname;
	PIMAGE_THUNK_DATA pThunk;
	DWORD oldProtect;
	hMod = GetModuleHandle(NULL);
	
	
	pAddr = (PBYTE)hMod;
	pAddr += *((DWORD*)&pAddr[0x3C]);
	pRVA = *((DWORD*)&pAddr[0x80]);
	
	pIDT = (PIMAGE_IMPORT_DESCRIPTOR)((DWORD)hMod + pRVA);
	
	//IMAGE_IMPORT_DESCRIPTOR�� RVA�� dllname�� �´��� �˻��ϸ� ��ĵ
	//Winmm.dll�� ��ġ �ľ�

	/*
	ULONG sz;
	//.idata import section�� �ּ�
	pIDT = (PIMAGE_IMPORT_DESCRIPTOR)ImageDirectoryEntryToData(hMod, TRUE, IMAGE_DIRECTORY_ENTRY_IMPORT, &sz);
	*/

	for (; pIDT->Name; pIDT++)
	{
		libname = (LPCSTR)((DWORD)hMod + pIDT->Name);

		//IDT���� ã���� �ϴ� dll�� ���� IMAGE_IMPORT_DESCRIPTOR�� ã�Ҵٸ�
		if (_stricmp(dllname, libname) == 0)
		{
			//ã�� DLL�� IAT�� �����ּ�
			pThunk = (PIMAGE_THUNK_DATA)((DWORD)hMod + pIDT->FirstThunk);

			for (; pThunk->u1.Function; pThunk++)
			{
				//���� �Լ� ��ġ �ľ�
				if (pThunk->u1.Function == (DWORD)func1)
				{				
					//�޸��� ��ȣ �Ӽ��� R/W�� ����
					VirtualProtect((LPVOID)&pThunk->u1.Function, sizeof(PROC), PAGE_EXECUTE_READWRITE, &oldProtect);
					
					pThunk->u1.Function = (DWORD)func2;

					VirtualProtect((LPVOID)&pThunk->u1.Function, sizeof(PROC), oldProtect, &oldProtect);
					return TRUE;
				}
			}
		}
	}
	return FALSE;
}

DWORD WINAPI MytimeGetTime()
{
	//Tick= timeGetTime();
	
	OutputDebugString("In MytimeGetTime()");
	
	return Tick;
}


void TickCounter()
{
	OutputDebugString("In TickCounter()");

	Tick = timeGetTime();
	
	while (1)
	{
		Tick += Count;
		Sleep(10);
	}
}
